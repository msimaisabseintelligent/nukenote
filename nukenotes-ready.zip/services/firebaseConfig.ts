// Go to Firebase Console > Project Settings > General > Your apps > SDK setup and configuration
// Copy the values from the firebaseConfig object and paste them here.

export const firebaseConfig = {
  apiKey: "AIzaSyCXKeH5_--wZClytyZ-YnlHbMAtLS-BYnc",
  authDomain: "nukenotes-296ed.firebaseapp.com",
  projectId: "nukenotes-296ed",
  storageBucket: "nukenotes-296ed.firebasestorage.app",
  messagingSenderId: "989848880540",
  appId: "1:989848880540:web:55264de3f8d1df03907459",
  measurementId: "G-HLFF8JHPLV"
};